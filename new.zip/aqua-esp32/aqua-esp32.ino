/*
  Aqua Smart - Smart Water Management System
  ESP32 DevKit + YF-S201 flow sensor (signal on GPIO 27 through a 10k/20k divider)

  What it does
  - Counts sensor pulses and works out flow (L/min) and litres used.
  - Serves the dashboard (data/index.html) from LittleFS, plus manifest.json and
    the app icons so it can be added to a phone's home screen as an app.
  - Sends live data to the dashboard at /api/data once a second.
  - Keeps litres per hour for today, today's running time and peak flow, and
    litres per day for up to the last 30 days.
  - Saves to flash once a minute while water is being used, so a power cut loses
    at most one minute.
  - Stores the device location name (e.g. "House kitchen") shown on the dashboard.
  - Stores the household profile (name, phone, place, people, colour) and the
    profile picture (/photo.txt in LittleFS). Re-uploading the data folder with
    the LittleFS tool erases the picture, so add it again afterwards.

  Clock
  - Hours and days need the real time. With home Wi-Fi the ESP32 gets it from the
    internet. Without home Wi-Fi it takes the time from the phone the first time the
    dashboard is opened. Until then, water is still counted in today's total and is
    added to the hourly chart as soon as the time is known.
  - A new day starts at midnight (Tanzania time). Restarting the ESP32 never starts
    a new day by itself.

  Wi-Fi
  - Always starts its own network "AquaSmart" (password aqua1234). Open http://192.168.4.1
  - If you fill in HOME_SSID below, it also joins your home Wi-Fi.

  Libraries: all built into the ESP32 Arduino core (WiFi, WebServer, LittleFS, Preferences).
  Tested to compile with ESP32 Arduino core 3.0.7, board "ESP32 Dev Module".
  Upload the "data" folder with the LittleFS upload tool, then upload this sketch.
*/
#include <WiFi.h>
#include <WebServer.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <time.h>
#include <sys/time.h>

// ---------- settings you can change ----------
const char* AP_SSID   = "AquaSmart";
const char* AP_PASS   = "aqua1234";      // at least 8 characters
const char* HOME_SSID = "";              // your home Wi-Fi name, or leave empty
const char* HOME_PASS = "";
const char* TZ_INFO   = "EAT-3";         // Tanzania time (UTC+3) in POSIX format
const long  TZ_OFFSET = 3 * 3600;        // the same offset in seconds
const int   SENSOR_PIN = 27;
// ---------------------------------------------

const int MAX_DAYS = 30;

WebServer server(80);
Preferences prefs;

portMUX_TYPE pulseMux = portMUX_INITIALIZER_UNLOCKED;
volatile uint32_t pulseCount = 0;        // pulses since the last 1-second read

uint32_t totalPulses = 0;
float kFactor = 7.5;                     // Hz per L/min (YF-S201 default; 450 pulses per litre)
float flowLmin = 0;
float todayL = 0;
float peakToday = 0;                     // highest flow today, L/min
int   peakMinute = -1;                   // minute of the day the peak happened, -1 = none yet
uint32_t runSecToday = 0;                // seconds water has flowed today
float hourly[24] = {0};
float pendingL = 0;                      // litres counted before the clock was known
float days[MAX_DAYS] = {0};              // days[MAX_DAYS-1] = yesterday
int   nDays = 0;                         // how many of days[] hold real measurements
long  lastDay = -1;                      // day number (days since 1970, Tanzania time) of "today"
String profileJson = "null";             // household profile, built from form fields
String devName = "";                     // where the device is placed, e.g. "House kitchen"
unsigned long lastTick = 0, lastSave = 0;
bool dirty = false;                      // something changed since the last save
bool staShown = false;

void IRAM_ATTR onPulse() {
  portENTER_CRITICAL_ISR(&pulseMux);
  pulseCount = pulseCount + 1;
  portEXIT_CRITICAL_ISR(&pulseMux);
}

// ---------- clock ----------
bool haveTime()   { return time(nullptr) > 1700000000; }
long dayNumber()  { return (long)((time(nullptr) + TZ_OFFSET) / 86400); }
int  localHour()  { time_t n = time(nullptr); struct tm t; localtime_r(&n, &t); return t.tm_hour; }
int  localMinute(){ time_t n = time(nullptr); struct tm t; localtime_r(&n, &t); return t.tm_hour * 60 + t.tm_min; }

// ---------- storage ----------
void loadSaved() {
  prefs.begin("aqua", false);
  kFactor     = prefs.getFloat("k", 7.5);
  todayL      = prefs.getFloat("today", 0);
  lastDay     = prefs.getLong("dayn", -1);    // new key: older firmware stored a different kind of day
  nDays       = constrain(prefs.getInt("ndays", 0), 0, MAX_DAYS);
  peakToday   = prefs.getFloat("peak", 0);
  peakMinute  = prefs.getInt("peakm", -1);
  runSecToday = prefs.getUInt("runs", 0);
  prefs.getBytes("hourly", hourly, sizeof(hourly));
  prefs.getBytes("days", days, sizeof(days));
  profileJson = prefs.getString("profile", "null");
  devName     = prefs.getString("devname", "");
}

void save() {
  prefs.putFloat("today", todayL);
  prefs.putLong("dayn", lastDay);
  prefs.putInt("ndays", nDays);
  prefs.putFloat("peak", peakToday);
  prefs.putInt("peakm", peakMinute);
  prefs.putUInt("runs", runSecToday);
  prefs.putBytes("hourly", hourly, sizeof(hourly));
  prefs.putBytes("days", days, sizeof(days));
  dirty = false;
  lastSave = millis();
}

void clearToday() {
  todayL = 0; peakToday = 0; peakMinute = -1; runSecToday = 0; pendingL = 0;
  for (int i = 0; i < 24; i++) hourly[i] = 0;
}

void pushDay(float litres) {
  for (int i = 0; i < MAX_DAYS - 1; i++) days[i] = days[i + 1];
  days[MAX_DAYS - 1] = litres;
  if (nDays < MAX_DAYS) nDays++;
}

// Called every second. Starts a new day at midnight, and fills in days the
// device was switched off with 0 L so the history stays in the right order.
void checkDay() {
  if (!haveTime()) return;                     // never guess the date
  long d = dayNumber();
  if (lastDay < 0) { lastDay = d; dirty = true; return; }
  if (d < lastDay) { lastDay = d; dirty = true; return; }   // clock moved back: keep today's data
  if (d == lastDay) return;
  long gap = d - lastDay;
  pushDay(todayL);
  for (long i = 1; i < gap && i <= MAX_DAYS; i++) pushDay(0);
  clearToday();
  lastDay = d;
  save();
}

// ---------- web helpers ----------
void cors() { server.sendHeader("Access-Control-Allow-Origin", "*"); }

// Make text safe to put inside a JSON string
String jsonEsc(const String& in, unsigned int maxLen) {
  String s = in.length() > maxLen ? in.substring(0, maxLen) : in;
  String o = "\"";
  for (unsigned int i = 0; i < s.length(); i++) {
    char c = s[i];
    if (c == '"' || c == '\\') { o += '\\'; o += c; }
    else if ((unsigned char)c < 0x20) o += ' ';
    else o += c;
  }
  return o + "\"";
}

// ---------- API ----------
// GET /api/data - everything the dashboard shows
void handleData() {
  String j;
  j.reserve(900);
  j = "{";
  j += "\"flow\":" + String(flowLmin, 2);
  j += ",\"today\":" + String(todayL, 2);
  j += ",\"pulses\":" + String(totalPulses);
  j += ",\"uptime\":" + String(millis() / 1000);
  j += ",\"k\":" + String(kFactor, 2);
  j += ",\"clock\":"; j += haveTime() ? "true" : "false";
  j += ",\"runSec\":" + String(runSecToday);
  j += ",\"peak\":" + String(peakToday, 2);
  j += ",\"peakAt\":" + String(peakMinute);
  j += ",\"profile\":" + profileJson;
  j += ",\"devName\":" + jsonEsc(devName, 30);
  j += ",\"hasPhoto\":"; j += LittleFS.exists("/photo.txt") ? "true" : "false";
  j += ",\"hourly\":[";
  for (int i = 0; i < 24; i++) { j += String(hourly[i], 1); if (i < 23) j += ","; }
  j += "],\"days\":[";                           // only days that were really measured, oldest first
  for (int i = MAX_DAYS - nDays; i < MAX_DAYS; i++) { j += String(days[i], 1); if (i < MAX_DAYS - 1) j += ","; }
  j += "]}";
  cors();
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", j);
}

// POST /api/settings?k=7.5&name=Kitchen
void handleSettings() {
  if (server.hasArg("k")) {
    float k = server.arg("k").toFloat();
    if (k > 1 && k < 50) { kFactor = k; prefs.putFloat("k", kFactor); }
  }
  if (server.hasArg("name")) {                 // device location; empty clears it
    devName = server.arg("name");
    devName.trim();
    if (devName.length() > 30) devName = devName.substring(0, 30);
    prefs.putString("devname", devName);
  }
  cors();
  server.send(200, "application/json", "{\"ok\":true,\"k\":" + String(kFactor, 2) + ",\"devName\":" + jsonEsc(devName, 30) + "}");
}

// POST /api/time?epoch=1762160000 - the phone's clock, used when there is no internet time
void handleTime() {
  long e = server.arg("epoch").toInt();
  cors();
  if (e < 1700000000) { server.send(400, "application/json", "{\"ok\":false,\"error\":\"epoch is missing or wrong\"}"); return; }
  long now = (long)time(nullptr);
  if (!haveTime() || labs(now - e) > 120) {
    struct timeval tv;
    tv.tv_sec = (time_t)e;
    tv.tv_usec = 0;
    settimeofday(&tv, nullptr);
    Serial.println("Clock set from the phone");
  }
  server.send(200, "application/json", "{\"ok\":true}");
}

// POST /api/reset - clears today only; past days are kept
void handleReset() {
  clearToday();
  save();
  cors();
  server.send(200, "application/json", "{\"ok\":true}");
}

// POST /api/profile  (form fields: name, phone, place, members, color)  or  delete=1
void handleProfile() {
  cors();
  if (server.hasArg("delete")) {
    profileJson = "null";
    LittleFS.remove("/photo.txt");
  } else if (server.hasArg("name") && server.arg("name").length() > 0) {
    int members = constrain((int)server.arg("members").toInt(), 1, 30);
    String color = server.arg("color");
    if (!(color.length() == 7 && color[0] == '#')) color = "#0f8b8d";
    profileJson = "{\"name\":" + jsonEsc(server.arg("name"), 40) +
                  ",\"phone\":" + jsonEsc(server.arg("phone"), 20) +
                  ",\"place\":" + jsonEsc(server.arg("place"), 40) +
                  ",\"members\":" + String(members) +
                  ",\"color\":" + jsonEsc(color, 7) + "}";
  } else {
    server.send(400, "application/json", "{\"ok\":false,\"error\":\"name is required\"}");
    return;
  }
  prefs.putString("profile", profileJson);
  server.send(200, "application/json", "{\"ok\":true,\"profile\":" + profileJson + "}");
}

// POST /api/photo - a small JPEG as a data URL (about 8-12 KB of text); an empty body removes it
void handlePhotoPost() {
  String b = server.arg("plain");
  cors();
  if (b.length() == 0) {
    LittleFS.remove("/photo.txt");
  } else {
    if (!b.startsWith("data:image/") || b.length() > 60000) {
      server.send(400, "application/json", "{\"ok\":false,\"error\":\"photo must be a small image\"}");
      return;
    }
    File f = LittleFS.open("/photo.txt", "w");
    if (!f) { server.send(500, "application/json", "{\"ok\":false,\"error\":\"could not save photo\"}"); return; }
    f.print(b);
    f.close();
  }
  server.send(200, "application/json", "{\"ok\":true}");
}

// GET /api/photo
void handlePhotoGet() {
  cors();
  if (!LittleFS.exists("/photo.txt")) { server.send(404, "text/plain", ""); return; }
  File f = LittleFS.open("/photo.txt", "r");
  server.streamFile(f, "text/plain");
  f.close();
}

void setup() {
  Serial.begin(115200);
  pinMode(SENSOR_PIN, INPUT);
  attachInterrupt(digitalPinToInterrupt(SENSOR_PIN), onPulse, FALLING);

  if (!LittleFS.begin(true)) Serial.println("LittleFS failed - did you upload the data folder?");
  loadSaved();

  setenv("TZ", TZ_INFO, 1);
  tzset();

  WiFi.mode(strlen(HOME_SSID) ? WIFI_AP_STA : WIFI_AP);
  WiFi.setSleep(false);                        // faster replies to the phone
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print("Dashboard: http://"); Serial.println(WiFi.softAPIP());
  if (strlen(HOME_SSID)) {
    WiFi.begin(HOME_SSID, HOME_PASS);
    configTzTime(TZ_INFO, "pool.ntp.org", "time.google.com");
  }

  server.on("/api/data", HTTP_GET, handleData);
  server.on("/api/settings", HTTP_POST, handleSettings);
  server.on("/api/time", HTTP_POST, handleTime);
  server.on("/api/reset", HTTP_POST, handleReset);
  server.on("/api/profile", HTTP_POST, handleProfile);
  server.on("/api/photo", HTTP_POST, handlePhotoPost);
  server.on("/api/photo", HTTP_GET, handlePhotoGet);
  server.serveStatic("/", LittleFS, "/index.html");
  // app files so the phone can add Aqua Smart to the home screen with its own icon
  server.serveStatic("/manifest.json", LittleFS, "/manifest.json", "max-age=86400");
  server.serveStatic("/icon-192.png", LittleFS, "/icon-192.png", "max-age=86400");
  server.serveStatic("/icon-512.png", LittleFS, "/icon-512.png", "max-age=86400");
  server.serveStatic("/apple-touch-icon.png", LittleFS, "/apple-touch-icon.png", "max-age=86400");
  server.onNotFound([]() { server.send(404, "text/plain", "Not found"); });
  server.begin();

  lastTick = millis();
  lastSave = millis();
}

void loop() {
  server.handleClient();

  unsigned long nowMs = millis();
  if (nowMs - lastTick >= 1000) {
    float dt = (nowMs - lastTick) / 1000.0;    // real time since the last reading
    lastTick = nowMs;

    uint32_t p;
    portENTER_CRITICAL(&pulseMux); p = pulseCount; pulseCount = 0; portEXIT_CRITICAL(&pulseMux);
    totalPulses += p;

    checkDay();

    flowLmin = (p / dt) / kFactor;             // pulses per second / factor = L/min
    float litres = p / (kFactor * 60.0);       // 1 L/min = k pulses per second, so 1 L = 60k pulses
    todayL += litres;
    if (p > 0) {
      runSecToday += (uint32_t)(dt + 0.5);
      dirty = true;
    }

    if (haveTime()) {
      int h = localHour();
      hourly[h] += litres + pendingL;
      pendingL = 0;
      if (flowLmin > peakToday) { peakToday = flowLmin; peakMinute = localMinute(); }
    } else {
      pendingL += litres;                      // placed in the right hour once the clock is known
      if (flowLmin > peakToday) peakToday = flowLmin;
    }

    if (!staShown && WiFi.status() == WL_CONNECTED) {
      Serial.print("Also on home Wi-Fi: http://"); Serial.println(WiFi.localIP());
      staShown = true;
    }
    if (p > 0) Serial.printf("Flow %.2f L/min | Today %.2f L\n", flowLmin, todayL);
  }

  if (dirty && millis() - lastSave > 60000) save();
}
